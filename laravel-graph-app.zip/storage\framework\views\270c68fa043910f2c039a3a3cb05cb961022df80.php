<?php $__env->startSection('content'); ?>
<div class="jumbotron">
  <h1>PHP Graph Tutorial</h1>
  <p class="lead">This sample app shows how to use the Microsoft Graph API to access Outlook and OneDrive data from PHP</p>
  <?php if(isset($userName)): ?>
    <h4>Welcome <?php echo e($userName); ?>!</h4>
    <p>Use the navigation bar at the top of the page to get started.</p>
  <?php else: ?>
    <a href="/signin" class="btn btn-primary btn-large">Click here to sign in</a>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapps\graph-tutorial\resources\views/welcome.blade.php ENDPATH**/ ?>