<?php $__env->startSection('content'); ?>
<h1>Groups </h1>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Group Name</th>
      <th scope="col">Subject</th>
      <th scope="col">Start</th>
      <th scope="col">End</th>
    </tr>
  </thead>
  <tbody>
    <?php if(isset($groups)): ?>
      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($group->getDisplayName()); ?></td>
          <td></td>
          <td></td>
          <td> </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapps\laravel-graph-app\resources\views/dashboard.blade.php ENDPATH**/ ?>