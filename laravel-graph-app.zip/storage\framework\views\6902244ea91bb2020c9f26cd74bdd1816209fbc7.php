<?php $__env->startSection('content'); ?>
<h1>Calendar</h1>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Organizer</th>
      <th scope="col">Subject</th>
      <th scope="col">Start</th>
      <th scope="col">End</th>
    </tr>
  </thead>
  <tbody>
    <?php if(isset($events)): ?>
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($event->getOrganizer()->getEmailAddress()->getName()); ?></td>
          <td><?php echo e($event->getSubject()); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($event->getStart()->getDateTime())->format('n/j/y g:i A')); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($event->getEnd()->getDateTime())->format('n/j/y g:i A')); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelapps\graph-tutorial\resources\views/calendar.blade.php ENDPATH**/ ?>